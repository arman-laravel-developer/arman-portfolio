

CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` longtext DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `status` tinyint(4) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO migrations VALUES("1","2014_10_12_000000_create_users_table","1");
INSERT INTO migrations VALUES("2","2014_10_12_100000_create_password_resets_table","1");
INSERT INTO migrations VALUES("3","2019_08_19_000000_create_failed_jobs_table","1");
INSERT INTO migrations VALUES("4","2019_12_14_000001_create_personal_access_tokens_table","1");
INSERT INTO migrations VALUES("5","2022_10_20_104110_create_posts_table","1");
INSERT INTO migrations VALUES("6","2014_10_12_200000_add_two_factor_columns_to_users_table","2");
INSERT INTO migrations VALUES("7","2022_10_25_092552_create_sessions_table","2");
INSERT INTO migrations VALUES("8","2022_10_26_133431_create_roles_table","3");
INSERT INTO migrations VALUES("9","2022_10_26_133512_create_role_routes_table","3");
INSERT INTO migrations VALUES("11","2022_10_30_144110_create_user_role_table","4");
INSERT INTO migrations VALUES("12","2022_10_31_093248_create_categories_table","5");
INSERT INTO migrations VALUES("13","2022_10_31_093426_create_sub_categories_table","5");
INSERT INTO migrations VALUES("14","2023_05_27_162722_create_sliders_table","6");
INSERT INTO migrations VALUES("18","2023_06_13_090710_create_privacies_table","8");



CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `sub_category_id` int(11) NOT NULL DEFAULT 0,
  `author_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `sub_title` varchar(255) DEFAULT NULL,
  `short_description` text NOT NULL,
  `long_description` longtext NOT NULL,
  `image` longtext NOT NULL,
  `hit_count` longtext NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `post_date` text DEFAULT NULL,
  `post_timestamp` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `privacies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `privacy` longtext DEFAULT NULL,
  `condition` longtext DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO privacies VALUES("2","<p class="MsoNormal" style="line-height: normal; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><font color="#212529" face="solaimanlipi, serif"><span style="font-size: 15.3333px;">fhgh</span></font></p><ul type="disc">
</ul>","<p>asdsadasdsad</p>","1","2023-06-13 09:35:34","2023-07-09 09:41:47");



CREATE TABLE `role_routes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `role_name` varchar(255) NOT NULL,
  `route_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO role_routes VALUES("78","1","Admin","user.add","2023-05-29 09:40:01","2023-05-29 09:40:01");
INSERT INTO role_routes VALUES("79","1","Admin","user.new","2023-05-29 09:40:01","2023-05-29 09:40:01");
INSERT INTO role_routes VALUES("80","1","Admin","user.manage","2023-05-29 09:40:01","2023-05-29 09:40:01");
INSERT INTO role_routes VALUES("81","1","Admin","user.edit","2023-05-29 09:40:01","2023-05-29 09:40:01");
INSERT INTO role_routes VALUES("82","1","Admin","user.update","2023-05-29 09:40:01","2023-05-29 09:40:01");
INSERT INTO role_routes VALUES("83","1","Admin","user.delete","2023-05-29 09:40:01","2023-05-29 09:40:01");
INSERT INTO role_routes VALUES("84","1","Admin","post.add","2023-05-29 09:40:02","2023-05-29 09:40:02");
INSERT INTO role_routes VALUES("85","1","Admin","post.new","2023-05-29 09:40:02","2023-05-29 09:40:02");
INSERT INTO role_routes VALUES("86","1","Admin","post.manage","2023-05-29 09:40:02","2023-05-29 09:40:02");
INSERT INTO role_routes VALUES("87","1","Admin","post.edit","2023-05-29 09:40:02","2023-05-29 09:40:02");
INSERT INTO role_routes VALUES("88","1","Admin","post.update","2023-05-29 09:40:02","2023-05-29 09:40:02");
INSERT INTO role_routes VALUES("89","1","Admin","post.delete","2023-05-29 09:40:02","2023-05-29 09:40:02");
INSERT INTO role_routes VALUES("90","1","Admin","role.add","2023-05-29 09:40:02","2023-05-29 09:40:02");
INSERT INTO role_routes VALUES("91","1","Admin","role.new","2023-05-29 09:40:02","2023-05-29 09:40:02");
INSERT INTO role_routes VALUES("92","1","Admin","role.manage","2023-05-29 09:40:02","2023-05-29 09:40:02");
INSERT INTO role_routes VALUES("93","1","Admin","role.edit","2023-05-29 09:40:02","2023-05-29 09:40:02");
INSERT INTO role_routes VALUES("94","1","Admin","role.update","2023-05-29 09:40:02","2023-05-29 09:40:02");
INSERT INTO role_routes VALUES("95","1","Admin","role.delete","2023-05-29 09:40:02","2023-05-29 09:40:02");
INSERT INTO role_routes VALUES("96","1","Admin","slider.add","2023-05-29 09:40:02","2023-05-29 09:40:02");
INSERT INTO role_routes VALUES("97","1","Admin","slider.new","2023-05-29 09:40:02","2023-05-29 09:40:02");
INSERT INTO role_routes VALUES("98","1","Admin","slider.manage","2023-05-29 09:40:02","2023-05-29 09:40:02");
INSERT INTO role_routes VALUES("99","1","Admin","slider.edit","2023-05-29 09:40:02","2023-05-29 09:40:02");
INSERT INTO role_routes VALUES("100","1","Admin","slider.update","2023-05-29 09:40:02","2023-05-29 09:40:02");
INSERT INTO role_routes VALUES("101","1","Admin","slider.delete","2023-05-29 09:40:02","2023-05-29 09:40:02");
INSERT INTO role_routes VALUES("102","1","Admin","category.add","2023-05-29 09:40:02","2023-05-29 09:40:02");
INSERT INTO role_routes VALUES("103","1","Admin","category.new","2023-05-29 09:40:02","2023-05-29 09:40:02");
INSERT INTO role_routes VALUES("104","1","Admin","category.manage","2023-05-29 09:40:02","2023-05-29 09:40:02");
INSERT INTO role_routes VALUES("105","1","Admin","category.edit","2023-05-29 09:40:02","2023-05-29 09:40:02");
INSERT INTO role_routes VALUES("106","1","Admin","category.update","2023-05-29 09:40:02","2023-05-29 09:40:02");
INSERT INTO role_routes VALUES("107","1","Admin","category.delete","2023-05-29 09:40:03","2023-05-29 09:40:03");
INSERT INTO role_routes VALUES("113","3","Reporter","post.add","2023-06-05 15:00:16","2023-06-05 15:00:16");
INSERT INTO role_routes VALUES("114","3","Reporter","post.new","2023-06-05 15:00:16","2023-06-05 15:00:16");
INSERT INTO role_routes VALUES("115","3","Reporter","post.manage","2023-06-05 15:00:17","2023-06-05 15:00:17");
INSERT INTO role_routes VALUES("116","3","Reporter","post.edit","2023-06-05 15:00:17","2023-06-05 15:00:17");
INSERT INTO role_routes VALUES("117","3","Reporter","post.update","2023-06-05 15:00:17","2023-06-05 15:00:17");



CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO roles VALUES("1","Admin","asdasdasd","2022-10-30 12:24:58","2023-05-23 09:20:31");
INSERT INTO roles VALUES("3","Reporter","asdasd","2022-10-30 14:08:54","2023-05-23 09:19:59");



CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO sessions VALUES("8cAh7lWYBMRB4C1PLfacx2DFV5kWlT59lhDy8FMy","","127.0.0.1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36","YTozOntzOjY6Il90b2tlbiI7czo0MDoiNTI4cEZsNFVwSk1GQWlDVkhFZWVNd3JpZHc1NDNYdDNSZ0xJVXRTZCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=","1716869504");
INSERT INTO sessions VALUES("aflJ9GLaqd0zLGwdjWyCWn1NGoIJW9Xer6TRITlT","1","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36","YTo1OntzOjY6Il90b2tlbiI7czo0MDoiUFo3Q2lBakpUUk5qZElIckxPaWNNUWZRWkRudjVDb0M5bTQyYzZvZSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTA6Imh0dHA6Ly9sb2NhbGhvc3QvbGFyYXZlbC1iYXNlbWVudC9wdWJsaWMvZGFzaGJvYXJkIjt9czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTtzOjIxOiJwYXNzd29yZF9oYXNoX3NhbmN0dW0iO3M6NjA6IiQyYSQxMiROL3B1Wi9obS8vckQyeWh6U3VjdGtPRXlUOTZMWVJXdm94NTNLd1FvZ1l6TWpxZC5WalI0RyI7fQ==","1688877355");
INSERT INTO sessions VALUES("cHpRNMYSLBF6wbhV3Un6NUmZgIdwLFBlZiZdHMMF","","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36","YTo0OntzOjY6Il90b2tlbiI7czo0MDoiZjd0b1I5blQ2UUdJQWZ4Y3pjc21HNmVnRmxFNzlOTTZkWFVobVI3TyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTM6Imh0dHA6Ly9sb2NhbGhvc3QvbGFyYXZlbC1iYXNlbWVudC9wdWJsaWMvY2F0ZWdvcnkvYWRkIjt9czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czo1MzoiaHR0cDovL2xvY2FsaG9zdC9sYXJhdmVsLWJhc2VtZW50L3B1YmxpYy9jYXRlZ29yeS9hZGQiO319","1703572202");
INSERT INTO sessions VALUES("ednEsh1DwKxctG55fIKdC0UguY8Ab9kwR2cN7TLO","","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36","YTozOntzOjY6Il90b2tlbiI7czo0MDoiV2g2ZUYxaUN3QVowTU5vZHJ3WTM5WUFJaDlNZ2psYXMzc0xBMVJUWCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzU6Imh0dHA6Ly9sb2NhbGhvc3QveW91dHViZS1hcGkvcHVibGljIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==","1705203757");
INSERT INTO sessions VALUES("EqBDRhPz7WClJVzsMH3VpfWpvoTVQJQPVMA2mOz2","","127.0.0.1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36","YTozOntzOjY6Il90b2tlbiI7czo0MDoiYTI3VVJZTGszNEw1c3V3cDhOR21GdnU0bUFPWW55NWVYWmhTNVh6TyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=","1716348646");
INSERT INTO sessions VALUES("g4ydYbVFLRCRE2GVCHPVnL7pTQZYsJAZ1NBZBvON","1","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36","YTo1OntzOjY6Il90b2tlbiI7czo0MDoiOXhWbEZTVUl4N2NIR3dzanNTMlVFTHFodldOOHdud2ZhWmQ1eWtRUiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDU6Imh0dHA6Ly9sb2NhbGhvc3Qvc3RyZWFtZmxpeC9wdWJsaWMvc2xpZGVyL2FkZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7czoyMToicGFzc3dvcmRfaGFzaF9zYW5jdHVtIjtzOjYwOiIkMmEkMTIkTi9wdVovaG0vL3JEMnloelN1Y3RrT0V5VDk2TFlSV3ZveDUzS3dRb2dZek1qcWQuVmpSNEciO30=","1705382121");
INSERT INTO sessions VALUES("L4VEoYUhw7ap1TlgZGI7OpaMfKUUXOv8BfUYIeDa","","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36","YTozOntzOjY6Il90b2tlbiI7czo0MDoiakdjZk5HSm15cHVETGRVYlhyYlQ3ZFJncVNDQ0ZseDlCd1VGOHBtQSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDA6Imh0dHA6Ly9sb2NhbGhvc3QvbGFyYXZlbC1iYXNlbWVudC9wdWJsaWMiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19","1705218868");
INSERT INTO sessions VALUES("p0hmOkF5Evtj6VgDTaw9CM46tkZgpaaVZAhlmglh","1","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36","YTo1OntzOjY6Il90b2tlbiI7czo0MDoiNW9OdWtJRUpyeEptZGR0WGJXU25UU09lYXUwaG9ydVJ4M3JhYkVndSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDY6Imh0dHA6Ly9sb2NhbGhvc3QvYXJtYW4tcG9ydGZvbGlvL3B1YmxpYy9iYWNrdXAiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO3M6MjE6InBhc3N3b3JkX2hhc2hfc2FuY3R1bSI7czo2MDoiJDJhJDEyJE4vcHVaL2htLy9yRDJ5aHpTdWN0a09FeVQ5NkxZUld2b3g1M0t3UW9nWXpNanFkLlZqUjRHIjt9","1719113504");
INSERT INTO sessions VALUES("tuZqJ5p21V603lHOsyNAglqgfuikxj4di7ZKB9hN","1","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36","YTo1OntzOjY6Il90b2tlbiI7czo0MDoiZWNVRU5relltY1RoTmt5NFY1anh5NlVROTF6VHBmeGVLNUhiQ0FCMiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzc6Imh0dHA6Ly9sb2NhbGhvc3QvYXBjb20td2VibWFpbC9wdWJsaWMiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO3M6MjE6InBhc3N3b3JkX2hhc2hfc2FuY3R1bSI7czo2MDoiJDJhJDEyJE4vcHVaL2htLy9yRDJ5aHpTdWN0a09FeVQ5NkxZUld2b3g1M0t3UW9nWXpNanFkLlZqUjRHIjt9","1703587574");
INSERT INTO sessions VALUES("Uh5Tsn40hgeQvD6oipSMakwkibwmrK2ZTnTK2NNS","","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36","YTozOntzOjY6Il90b2tlbiI7czo0MDoiSmlzd2Z3V2xOS1poZGVtbjFndUl2d2hNUGpYWlpqUmhEU0lyZUs5ayI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDA6Imh0dHA6Ly9sb2NhbGhvc3QvbGFyYXZlbC1iYXNlbWVudC9wdWJsaWMiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19","1693368085");
INSERT INTO sessions VALUES("YArEeTJc3FaF4nOAoPgkOAplPp54ndS7AVczyxOH","1","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36","YTo1OntzOjY6Il90b2tlbiI7czo0MDoiMVQyWURvckJwaVdmN0tFcVNHOE1hN2ltOFVKR2R0WnVpRnJHU29DUyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDY6Imh0dHA6Ly9sb2NhbGhvc3QvbGFyYXZlbC1iYXNlbWVudC9wdWJsaWMvbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO3M6MjE6InBhc3N3b3JkX2hhc2hfc2FuY3R1bSI7czo2MDoiJDJhJDEyJE4vcHVaL2htLy9yRDJ5aHpTdWN0a09FeVQ5NkxZUld2b3g1M0t3UW9nWXpNanFkLlZqUjRHIjt9","1692698429");
INSERT INTO sessions VALUES("Z28BQsFMzsvhI5IXvRpHXKiKesVFAfd1J1GGh5sM","1","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36","YTo2OntzOjY6Il90b2tlbiI7czo0MDoiamNTbmNaelRiejlJSHRyOEhwQmR3Z01QWVJsSGtqclR3RXFFa1pGeiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTY6Imh0dHA6Ly9sb2NhbGhvc3QvbGFyYXZlbC1iYXNlbWVudC9wdWJsaWMvY2F0ZWdvcnkvbWFuYWdlIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTtzOjIxOiJwYXNzd29yZF9oYXNoX3NhbmN0dW0iO3M6NjA6IiQyYSQxMiROL3B1Wi9obS8vckQyeWh6U3VjdGtPRXlUOTZMWVJXdm94NTNLd1FvZ1l6TWpxZC5WalI0RyI7czo1OiJhbGVydCI7YTowOnt9fQ==","1688875723");
INSERT INTO sessions VALUES("ZJRX8LaljTX7KvSAGiE3RLG9B29e3o4yWA04Sqsh","","::1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36","YTozOntzOjY6Il90b2tlbiI7czo0MDoid2E3T3lIeGhiaTBwbllLSjR0VjhiOW9lTkY5d2dRRktpY1czT0JMQyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDA6Imh0dHA6Ly9sb2NhbGhvc3QvbGFyYXZlbC1iYXNlbWVudC9wdWJsaWMiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19","1688876421");



CREATE TABLE `sliders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `short_description` text DEFAULT NULL,
  `image` text DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `sub_categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `user_role` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `two_factor_secret` text DEFAULT NULL,
  `two_factor_recovery_codes` text DEFAULT NULL,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `mobile` varchar(255) NOT NULL DEFAULT '0',
  `image` varchar(255) DEFAULT NULL,
  `user_type` tinyint(4) NOT NULL DEFAULT 0,
  `access_label` tinyint(4) NOT NULL DEFAULT 0,
  `website_status` tinyint(4) NOT NULL DEFAULT 1,
  `login_status` tinyint(4) NOT NULL DEFAULT 1,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO users VALUES("1","Super Admin","admin@gmail.com","","$2a$12$N/puZ/hm//rD2yhzSuctkOEyT96LYRWvox53KwQogYzMjqd.VjR4G","","","","0","user-images/1687774120.jpg","1","0","1","1","","2022-10-25 09:28:53","2023-06-26 16:08:40");

